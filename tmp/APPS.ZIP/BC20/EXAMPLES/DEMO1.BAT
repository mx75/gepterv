make -fwhereis.mak
